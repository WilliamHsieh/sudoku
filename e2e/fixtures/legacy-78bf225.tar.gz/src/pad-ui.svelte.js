// Ephemeral keypad / undo-ring visuals. Not game state: Svelte reads these so
// classes survive a re-render (classList.add would be overwritten).

/**
 * @typedef {'add' | 'remove'} PreviewKind
 * @typedef {{ cell: number, d: number, kind: PreviewKind } | null} Preview
 * @typedef {{ cell: number, d: number } | null} PendingNote
 */

/**
 * @typedef {Object} KeyGestureView
 * @property {number} d
 * @property {boolean} pressed
 * @property {boolean} holding
 * @property {boolean} armed
 * @property {boolean} armLock
 * @property {boolean} remove
 * @property {boolean} illegal
 * @property {boolean} showLabel
 * @property {string} label
 * @property {string} bottom
 */

/**
 * Second finger while a key is held.
 * @typedef {Object} KeyHold
 * @property {number} d
 * @property {number} pid
 * @property {number} travel
 * @property {number} toggled
 * @property {boolean} painting
 */

export const padUi = $state({
  /** @type {{ i: number, t: number, hl: number }} */
  lastTap: { i: -1, t: -Infinity, hl: 0 },
  /** @type {Preview} */
  preview: null,
  /** @type {PendingNote} */
  pending: null,
  /** @type {number[]} */
  blocking: [],
  /** @type {number[]} */
  blocked: [],
  /** @type {number[]} */
  undoTargets: [],
  quiet: false,
  /** Digit highlighted on the keypad and the board. 0 = none. Selection does not add its own. */
  shown: 0,
  /** Locked digit. 0 = none. Never persisted. */
  locked: 0,
  /** Toast over the board, or "". */
  toast: "",
  /** @type {ReturnType<typeof import('./game/paint.js').strokeMarks> | null} */
  marks: null,
  finger: -1,
  announcement: "",
  commitId: 0,
  /** @type {KeyGestureView | null} */
  gesture: null,
  /** @type {KeyHold | null} */
  hold: null,
  /** @type {{ d: number, cell: number, locked: boolean, engaged: boolean, painting: boolean } | null} */
  spaceHold: null,
  /** First-run coach over the keypad. */
  coach: false,
  /** Digit whose glyph is hidden while it flies. 0 = none. */
  lifted: 0,
});
