// Disposable local backend: answers whether the two JVM engines can serve the real App.
import http from "node:http";
import { spawn, execFileSync } from "node:child_process";
import { createInterface } from "node:readline";
import { mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { performance } from "node:perf_hooks";
import { build } from "vite";
import { svelte } from "@sveltejs/vite-plugin-svelte";

const root = fileURLToPath(new URL("../../../", import.meta.url));
const engineHome = process.env.SUDOKU_ENGINE_HOME ?? "/tmp/sudoku-all-technique-latency";
const work = "/tmp/sudoku-engine-app-prototype";
const java =
  process.env.SUDOKU_JAVA_BIN ?? path.join(engineHome, "jdk-17.0.21+9/Contents/Home/bin/java");
const javac = java.replace(/java$/, "javac");
const classes = path.join(work, "classes");
const classpath = [
  classes,
  path.join(engineHome, "SukakuExplainer.jar"),
  path.join(engineHome, "hodoku-classes"),
  path.join(engineHome, "Hodoku/src"),
].join(path.delimiter);

class EngineProcess {
  constructor(engine) {
    this.engine = engine;
    this.queue = [];
    this.running = false;
    this.sequence = 0;
    this.child = null;
    this.ready = null;
    this.active = null;
    this.pending = null;
    this.log = [];
  }
  async start() {
    if (this.child) {
      await this.ready;
      return 0;
    }
    const began = performance.now();
    const child = spawn(
      java,
      ["-Djava.awt.headless=true", "-cp", classpath, "JavaHintBridgePrototype"],
      { cwd: work, stdio: ["pipe", "pipe", "pipe"] }
    );
    this.child = child;
    this.ready = new Promise((resolve, reject) => {
      let settled = false;
      const timeout = setTimeout(() => {
        reject(Error("Java startup timed out"));
        this.stop();
      }, 15000);
      createInterface({ input: child.stderr }).on("line", (line) => {
        this.log.push(line);
        this.log = this.log.slice(-20);
        if (line.startsWith("READY") && !settled) {
          settled = true;
          clearTimeout(timeout);
          resolve();
        }
      });
      createInterface({ input: child.stdout }).on("line", (line) => {
        let result;
        try {
          result = JSON.parse(line);
        } catch {
          this.log.push(line);
          return;
        }
        if (
          this.pending &&
          this.pending.child === child &&
          String(result.id) === String(this.pending.id)
        ) {
          const pending = this.pending;
          this.pending = null;
          clearTimeout(pending.timer);
          if (result.error) pending.reject(Error(result.error));
          else pending.resolve(result);
        }
      });
      const fail = (error) => {
        clearTimeout(timeout);
        if (!settled) {
          settled = true;
          reject(error);
        }
        if (this.child === child) {
          this.child = null;
          this.ready = null;
        }
        if (this.pending?.child === child) {
          const p = this.pending;
          this.pending = null;
          clearTimeout(p.timer);
          p.reject(error);
        }
      };
      child.on("error", fail);
      child.on("exit", (code, signal) => fail(Error(`Java process stopped (${code ?? signal})`)));
    });
    await this.ready;
    return performance.now() - began;
  }
  stop() {
    const child = this.child;
    this.child = null;
    this.ready = null;
    child?.kill("SIGKILL");
  }
  request(payload, { signal, timeoutMs = 10000 } = {}) {
    return new Promise((resolve, reject) => {
      const job = {
        payload,
        signal,
        timeoutMs,
        resolve,
        reject,
        queued: performance.now(),
        cancelled: false,
      };
      const cancel = () => {
        job.cancelled = true;
        if (this.active === job) this.stop();
        reject(Object.assign(Error("Request cancelled"), { name: "AbortError" }));
      };
      job.cleanup = () => signal?.removeEventListener("abort", cancel);
      if (signal?.aborted) {
        cancel();
        return;
      }
      signal?.addEventListener("abort", cancel, { once: true });
      this.queue.push(job);
      void this.drain();
    });
  }
  async drain() {
    if (this.running) return;
    this.running = true;
    while (this.queue.length) {
      const job = this.queue.shift();
      if (job.cancelled) {
        job.cleanup();
        continue;
      }
      this.active = job;
      try {
        const coldStartMs = await this.start();
        if (job.cancelled) continue;
        const queueMs = performance.now() - job.queued - coldStartMs;
        const id = ++this.sequence;
        const result = await new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            this.pending = null;
            reject(Error("Search deadline exceeded"));
            this.stop();
          }, job.timeoutMs);
          this.pending = { id, resolve, reject, timer, child: this.child };
          this.child.stdin.write(
            JSON.stringify({ ...job.payload, id, engine: this.engine }) + "\n"
          );
        });
        if (!job.cancelled)
          job.resolve({
            ...result,
            coldStartMs,
            queueMs,
            backendRoundTripMs: performance.now() - job.queued,
          });
      } catch (error) {
        if (!job.cancelled) job.reject(error);
      } finally {
        job.cleanup();
        this.active = null;
      }
    }
    this.running = false;
  }
}

async function appHtml() {
  const built = await build({
    root,
    configFile: false,
    base: "./",
    logLevel: "error",
    plugins: [svelte()],
    define: { __SUDOKU_BUILD__: "undefined" },
    build: {
      write: false,
      cssCodeSplit: false,
      lib: {
        entry: path.join(root, "src/hints/engines/client.prototype.mjs"),
        formats: ["iife"],
        name: "EngineAppPrototype",
      },
    },
  });
  const output = (Array.isArray(built) ? built[0] : built).output;
  const js = output
    .filter((x) => x.type === "chunk")
    .map((x) => x.code)
    .join("\n");
  const css = output
    .filter((x) => x.type === "asset" && x.fileName.endsWith(".css"))
    .map((x) => String(x.source))
    .join("\n");
  return (
    '<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sudoku engine prototype</title><style>' +
    css +
    '</style></head><body><div id="app"></div><script>localStorage.setItem("sudoku-keypad-coach","1")</script><script>' +
    js.replaceAll("</script", "<\\/script") +
    "</script></body></html>"
  );
}

export async function startEnginePrototype({ port = 8766 } = {}) {
  await mkdir(classes, { recursive: true });
  execFileSync(
    javac,
    [
      "-cp",
      classpath,
      "-d",
      classes,
      path.join(root, "src/hints/engines/JavaHintBridgePrototype.java"),
    ],
    { cwd: work, stdio: "pipe" }
  );
  const html = await appHtml();
  const engines = { se: new EngineProcess("se"), hodoku: new EngineProcess("hodoku") };
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, "http://localhost");
    const json = (status, value) => {
      if (!res.destroyed) {
        res.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store" });
        res.end(JSON.stringify(value));
      }
    };
    if (req.method === "GET" && url.pathname === "/") {
      res.writeHead(200, {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
      });
      res.end(html);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/health") {
      json(200, {
        prototype: true,
        engines: Object.keys(engines),
        java,
        processes: Object.fromEntries(
          Object.entries(engines).map(([key, value]) => [key, !!value.child])
        ),
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/reset") {
      const engine = url.searchParams.get("engine");
      if (!engines[engine]) return json(400, { error: "Unknown engine" });
      engines[engine].stop();
      json(200, { reset: engine });
      return;
    }
    if (req.method !== "POST" || url.pathname !== "/api/hint") {
      res.writeHead(404);
      res.end();
      return;
    }
    const started = performance.now(),
      controller = new AbortController();
    res.on("close", () => {
      if (!res.writableFinished) controller.abort();
    });
    try {
      let body = "";
      for await (const chunk of req) {
        body += chunk;
        if (body.length > 100000) throw Error("Request too large");
      }
      const input = JSON.parse(body),
        engine = engines[input.engine];
      if (
        !engine ||
        !/^[0-9]{81}$/.test(input.values) ||
        !Array.isArray(input.candidates) ||
        input.candidates.length !== 81 ||
        input.candidates.some((x) => !Number.isInteger(x) || x < 0 || x > 1022 || x & 1)
      )
        return json(400, { error: "Invalid engine/board/candidate masks" });
      const result = await engine.request(input, { signal: controller.signal, timeoutMs: 10000 });
      json(200, { ...result, serverMs: performance.now() - started });
    } catch (error) {
      json(error.name === "AbortError" ? 499 : 503, { error: error.message });
    }
  });
  await new Promise((resolve) => server.listen(port, "127.0.0.1", resolve));
  const address = server.address();
  return {
    url: `http://127.0.0.1:${address.port}`,
    engines,
    close: async () => {
      Object.values(engines).forEach((e) => e.stop());
      await new Promise((resolve) => server.close(resolve));
    },
  };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const app = await startEnginePrototype({ port: Number(process.env.SUDOKU_ENGINE_PORT ?? 8766) });
  console.log(`SE: ${app.url}/?engine=se&case=xwing\nHoDoKu: ${app.url}/?engine=hodoku&case=xwing`);
  const stop = async () => {
    await app.close();
    process.exit(0);
  };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
}
