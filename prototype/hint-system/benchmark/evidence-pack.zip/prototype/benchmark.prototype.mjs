// Benchmarks the actual App/provider/HTTP/JVM path, not a timed replay of hints.
import { chromium } from "@playwright/test";
import { mkdir, writeFile, rm } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { performance } from "node:perf_hooks";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { startEnginePrototype } from "./server.prototype.mjs";

const root = fileURLToPath(new URL("../../../", import.meta.url));
const out = path.join(root, ".lavish/hint-engine-prototype");
await mkdir(out, { recursive: true });
const began = performance.now();
const app = await startEnginePrototype({ port: 0 });
const buildAndCompileMs = performance.now() - began;
const browser = await chromium.launch();
const errors = [],
  rows = [],
  raw = [];
const fields = [
  "displayMs",
  "fetchMs",
  "searchMs",
  "adapterMs",
  "serverMs",
  "coldStartMs",
  "queueMs",
];
const percentile = (xs, p) =>
  [...xs].sort((a, b) => a - b)[Math.max(0, Math.ceil(xs.length * p) - 1)];
async function waitReady(page) {
  await page.waitForSelector('body[data-engine-prototype="ready"]');
  await page
    .locator(".play")
    .evaluate((el) => Promise.all(el.getAnimations().map((a) => a.finished)));
}
async function openHint(page) {
  const count = await page.evaluate(() => window.engineLab.events.length);
  await page.evaluate(() => {
    window.engineLab.nextClickAt = performance.now();
    document.getElementById("hint-trigger").click();
  });
  await page.waitForFunction(
    (count) => window.engineLab.events.length > count && window.engineLab.last.done,
    count
  );
  const event = await page.evaluate(() => window.engineLab.last);
  if (event.error || event.noResult || !Number.isFinite(event.displayMs))
    throw Error(JSON.stringify(event));
  return event;
}
async function closeHint(page) {
  await page.locator(".hint-close").click();
  await page.locator(".hint-panel").waitFor({ state: "detached" });
}
try {
  if (!process.argv.includes("--capture-only"))
    for (const engine of ["se", "hodoku"]) {
      const context = await browser.newContext({ viewport: { width: 1600, height: 1000 } });
      const page = await context.newPage();
      page.on("pageerror", (e) => errors.push(e.message));
      for (const fixture of ["hidden", "pair", "xwing"]) {
        await page.goto(`${app.url}/?engine=${engine}&case=${fixture}`);
        await waitReady(page);
        // Warming the browser/Java path is distinct from JVM-cold requests below.
        for (let i = 0; i < 5; i++) {
          await openHint(page);
          await closeHint(page);
        }
        for (const condition of ["warm", "cold-jvm"]) {
          const samples = [];
          for (let i = 0; i < 20; i++) {
            if (condition === "cold-jvm")
              await fetch(`${app.url}/api/reset?engine=${engine}`, { method: "POST" });
            const event = await openHint(page);
            samples.push(event);
            raw.push({ engine, fixture, condition, iteration: i + 1, ...event });
            await closeHint(page);
          }
          rows.push({
            engine,
            fixture,
            condition,
            n: samples.length,
            techniques: [...new Set(samples.map((x) => x.technique))],
            ...Object.fromEntries(
              fields.map((field) => [
                field,
                {
                  p50Ms: percentile(
                    samples.map((s) => s[field]),
                    0.5
                  ),
                  p99Ms: percentile(
                    samples.map((s) => s[field]),
                    0.99
                  ),
                },
              ])
            ),
          });
          console.log(
            `${engine}/${fixture}/${condition}: display P50=${rows.at(-1).displayMs.p50Ms.toFixed(2)} P99=${rows.at(-1).displayMs.p99Ms.toFixed(2)} ms`
          );
          await writeFile(
            path.join(out, "app-latency.json"),
            JSON.stringify(
              {
                metadata: {
                  hardware: "Apple M3 desktop Chromium, Java 17; no physical phone",
                  nPerBoard: 20,
                  warmup: 5,
                  percentile: "nearest rank; n=20 P99 equals max",
                  condition:
                    "cold-jvm restarts only the JVM; frontend and local HTTP service stay warm",
                  timing:
                    "displayMs: Hint click to ready DOM + two animation frames. adapterMs includes search, input reconstruction and explanation. Local loopback HTTP only.",
                  priority: "engine-native-first-result, not common SudokuWiki ranking",
                  buildAndCompileMs,
                },
                rows,
                raw,
              },
              null,
              2
            )
          );
        }
      }
      await context.close();
    }
  const cols = [
    "engine",
    "fixture",
    "condition",
    "n",
    "techniques",
    ...fields.flatMap((f) => [f + "_P50_ms", f + "_P99_ms"]),
  ];
  if (rows.length)
    await writeFile(
      path.join(out, "app-latency.csv"),
      [
        cols.join(","),
        ...rows.map((r) =>
          [
            r.engine,
            r.fixture,
            r.condition,
            r.n,
            r.techniques.join("|"),
            ...fields.flatMap((f) => [r[f].p50Ms, r[f].p99Ms]),
          ].join(",")
        ),
      ].join("\n")
    );
  async function click(page, selector, wait = 1200) {
    const el = page.locator(selector).first();
    await el.scrollIntoViewIfNeeded();
    const r = await el.boundingBox();
    await page.evaluate(
      ({ x, y }) => {
        document.querySelector(".record-pointer").style.transform =
          `translate(${x - 8}px,${y - 8}px)`;
      },
      { x: r.x + r.width / 2, y: r.y + r.height / 2 }
    );
    await page.waitForTimeout(150);
    await el.click();
    await page.waitForTimeout(wait);
  }
  for (const engine of ["se", "hodoku"])
    for (const [device, viewport] of [
      ["desktop", { width: 1600, height: 1000 }],
      ["mobile", { width: 390, height: 844 }],
    ]) {
      const context = await browser.newContext({
        viewport,
        hasTouch: device === "mobile",
        recordVideo: { dir: path.join(out, "raw-video"), size: viewport },
      });
      const page = await context.newPage();
      page.on("pageerror", (e) => errors.push(e.message));
      await page.goto(`${app.url}/?engine=${engine}&case=xwing`);
      await waitReady(page);
      await page.addStyleTag({
        content:
          ".record-pointer{position:fixed;left:0;top:0;width:16px;height:16px;border:2px solid white;border-radius:50%;background:rgba(42,86,198,.7);box-shadow:0 0 0 5px rgba(42,86,198,.15);transform:translate(-50px,-50px);transition:transform .2s;pointer-events:none;z-index:100}",
      });
      await page.evaluate(() => {
        const p = document.createElement("div");
        p.className = "record-pointer";
        document.body.append(p);
      });
      await fetch(`${app.url}/api/reset?engine=${engine}`, { method: "POST" });
      const baseline = await page.locator(".board").boundingBox();
      await page.waitForTimeout(700);
      await click(page, "#hint-trigger", 1600);
      await page.waitForSelector(".hint-progress");
      await click(page, '[data-action="next"]', 2300);
      const current = await page.locator(".board").boundingBox();
      if (Math.abs(current.width - baseline.width) > 0.8 || Math.abs(current.y - baseline.y) > 0.8)
        throw Error("Board moved");
      await page.screenshot({ path: path.join(out, `${engine}-${device}-reasoning.png`) });
      if (device === "mobile") {
        await page.locator(".hint-body").hover();
        await page.mouse.wheel(0, 300);
        await page.waitForTimeout(1600);
      }
      await click(page, '[data-action="next"]', 2000);
      await page.screenshot({ path: path.join(out, `${engine}-${device}-conclusion.png`) });
      const effect = await page.evaluate(() => window.engineLab.last.effect);
      if (!effect.includes("1")) throw Error("Unexpected fixture effect");
      const before = await page
        .locator(".cell")
        .evaluateAll((cells) =>
          cells.map((c) => [c.getAttribute("data-value"), c.getAttribute("data-notes")])
        );
      await click(page, '[data-action="apply"]', 1300);
      await page.getByRole("heading", { name: "這一步已完成" }).waitFor();
      await click(page, '[data-action="undo"]', 1200);
      const after = await page
        .locator(".cell")
        .evaluateAll((cells) =>
          cells.map((c) => [c.getAttribute("data-value"), c.getAttribute("data-notes")])
        );
      if (JSON.stringify(before) !== JSON.stringify(after))
        throw Error("Live hint undo did not restore board");
      const video = page.video();
      await context.close();
      const converted = spawnSync(
        "ffmpeg",
        [
          "-y",
          "-i",
          await video.path(),
          "-an",
          "-c:v",
          "libx264",
          "-preset",
          "veryfast",
          "-crf",
          "20",
          "-pix_fmt",
          "yuv420p",
          "-movflags",
          "+faststart",
          path.join(out, `${engine}-${device}.mp4`),
        ],
        { encoding: "utf8" }
      );
      if (converted.status !== 0) throw Error(converted.stderr);
      console.log(`Recorded live ${engine}/${device}`);
    }
  await rm(path.join(out, "raw-video"), { recursive: true, force: true });
  if (errors.length) throw Error(errors.join("\n"));
} finally {
  await browser.close();
  await app.close();
}
