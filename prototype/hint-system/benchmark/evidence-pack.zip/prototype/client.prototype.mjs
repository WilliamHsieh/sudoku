// Real App -> HTTP -> persistent Java prototype; no solver steps are replayed.
import "../../app.css";
import { mount, tick } from "svelte";
import App from "../../App.svelte";
import { game } from "../../game/game.svelte.js";
import { computedCandidates, valueAt } from "../../game/game.js";
import { bit, maskDigits, PEERS } from "../../game/board.js";
import { hintFixture } from "../fixtures.prototype.mjs";
import { applyHint, hintStateKey } from "../hint.js";
import { timer, timerRunning } from "../../store.js";

const rc = (i) => `r${Math.floor(i / 9) + 1}c${(i % 9) + 1}`;
const list = (cells) => cells.map(rc).join("、");
const stage = (title, description, coordinates = []) => ({
  title,
  description: Array.isArray(description) ? description : [description],
  coordinates,
});
function normalize(raw) {
  const placements = raw.placements ?? [],
    eliminations = raw.eliminations ?? [];
  const sources = [...new Set(raw.premiseCells ?? [])];
  const targets = [...new Set([...placements, ...eliminations].map((p) => p.cell))];
  const effect = [
    ...placements.map((p) => `${rc(p.cell)}：填入 ${p.digit}。`),
    ...eliminations.map((p) => `${rc(p.cell)}：刪除候選數 ${p.digit}。`),
  ].join(" ");
  const description = String(raw.description ?? raw.name)
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  let observe = raw.observeCells?.length ? raw.observeCells : sources;
  let stages = [
    stage("觀察標示的格子。", "找找看，這些格子之間有哪些限制關係？"),
    stage(`這一步使用 ${raw.name}。`, description, sources),
    stage(placements.length ? "這些格子可以確定填數。" : "這些候選數可以刪除。", effect, targets),
  ];
  const masks = raw.candidateMasks;
  const digit = eliminations[0]?.digit;
  const rows = [...new Set(sources.map((i) => Math.floor(i / 9)))].sort((a, b) => a - b);
  const cols = [...new Set(sources.map((i) => i % 9))].sort((a, b) => a - b);
  if (
    /x.?wing/i.test(raw.name) &&
    sources.length === 4 &&
    rows.length === 2 &&
    cols.length === 2 &&
    digit
  ) {
    const rowLocked = rows.every((r) =>
      Array.from({ length: 9 }, (_, c) => r * 9 + c)
        .filter((i) => masks[i] & bit(digit))
        .every((i) => sources.includes(i))
    );
    const colLocked = cols.every((c) =>
      Array.from({ length: 9 }, (_, r) => r * 9 + c)
        .filter((i) => masks[i] & bit(digit))
        .every((i) => sources.includes(i))
    );
    if (rowLocked || colLocked) {
      const units = rowLocked ? rows : cols,
        opposite = rowLocked ? cols : rows;
      const label = rowLocked ? "橫列" : "直行",
        other = rowLocked ? "直行" : "橫列";
      const unitText = units.map((n) => n + 1).join("、"),
        otherText = opposite.map((n) => n + 1).join("、");
      observe = Array.from({ length: 81 }, (_, i) =>
        units.includes(rowLocked ? Math.floor(i / 9) : i % 9) ? i : -1
      ).filter((i) => i >= 0);
      const facts = units.map(
        (n) =>
          `第 ${n + 1} ${label}只有 ${list(sources.filter((i) => (rowLocked ? Math.floor(i / 9) : i % 9) === n))} 能填 ${digit}。`
      );
      stages = [
        stage(`觀察第 ${unitText} ${label}的候選數 ${digit}。`, "它們的位置有什麼共同點？"),
        stage(
          `兩個${label}的 ${digit}，都落在第 ${otherText} ${other}。`,
          [
            ...facts,
            `兩個${label}各需要一個 ${digit}，而且同一${other}不能重複，因此這兩個 ${digit} 必須分別占住第 ${otherText} ${other}。`,
            `四個藍框格形成 X-Wing。這兩個${other}的其他格都不能再填 ${digit}。`,
          ],
          sources
        ),
        stage(`另外 ${targets.length} 格可以刪除候選數 ${digit}。`, effect, targets),
      ];
    }
  } else if (
    /naked.?single|full.?house/i.test(raw.name) &&
    placements.length === 1 &&
    maskDigits(masks[placements[0].cell]).length === 1
  ) {
    const { cell, digit } = placements[0];
    observe = [cell];
    stages = [
      stage(`觀察 ${rc(cell)} 的候選數。`, "這一格還有哪些數字可以填？"),
      stage(`這一格只剩下 ${digit}。`, `${rc(cell)} 的其他數字都已被排除，因此只能填 ${digit}。`, [
        cell,
      ]),
      stage(`${rc(cell)} 必須填入 ${digit}。`, effect, [cell]),
    ];
  } else if (/hidden.?single/i.test(raw.name) && placements.length === 1) {
    const { cell, digit } = placements[0],
      r = Math.floor(cell / 9),
      c = cell % 9;
    const units = [
      { label: `第 ${r + 1} 橫列`, cells: Array.from({ length: 9 }, (_, i) => r * 9 + i) },
      { label: `第 ${c + 1} 直行`, cells: Array.from({ length: 9 }, (_, i) => i * 9 + c) },
      {
        label: `第 ${Math.floor(r / 3) * 3 + Math.floor(c / 3) + 1} 宮`,
        cells: Array.from(
          { length: 9 },
          (_, i) => Math.floor(r / 3) * 27 + Math.floor(c / 3) * 3 + Math.floor(i / 3) * 9 + (i % 3)
        ),
      },
    ];
    const unit = units.find((u) => u.cells.filter((i) => masks[i] & bit(digit)).length === 1);
    if (unit) {
      observe = unit.cells;
      stages = [
        stage(`觀察${unit.label}的數字 ${digit}。`, "找找看，哪些空格還能填這個數字？"),
        stage(
          `${unit.label}只有 ${rc(cell)} 能填 ${digit}。`,
          `${unit.label}一定要有 ${digit}；其他空格都已被排除，因此這個數字只能填在 ${rc(cell)}。`,
          [cell]
        ),
        stage(`${rc(cell)} 必須填入 ${digit}。`, effect, [cell]),
      ];
    }
  }
  return {
    techniqueId: raw.techniqueId,
    name: raw.name,
    stages,
    observeCells: observe,
    premiseCells: sources,
    premiseCandidates: raw.premiseCandidates ?? [],
    excludedCandidates: raw.excludedCandidates ?? [],
    placements,
    eliminations,
    candidateMasks: masks,
    effect,
  };
}

async function start() {
  const params = new URLSearchParams(location.search),
    engine = params.get("engine") === "hodoku" ? "hodoku" : "se";
  const fixture = hintFixture(params.get("case") ?? "xwing");
  const certificates = new Map([[hintStateKey(fixture.state), fixture.hint.candidateMasks]]);
  // Exact immutable-state keys keep undo and player note edits from becoming proof premises.
  const lab = { engine, events: [], last: null, nextClickAt: null };
  window.engineLab = lab;
  const observer = new MutationObserver(() => {
    const event = lab.last;
    if (!event || !event.responseAt || event.domAt || event.error) return;
    if (!document.querySelector(".hint-progress")) return;
    event.domAt = performance.now();
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        event.displayMs = performance.now() - event.clickAt;
        event.done = true;
        document.body.dataset.engineHintReady = String(event.id);
      })
    );
  });
  observer.observe(document.getElementById("app"), { childList: true, subtree: true });
  const provider = async (state, { signal }) => {
    const began = performance.now();
    const event = {
      id: lab.events.length + 1,
      engine,
      clickAt: lab.nextClickAt ?? began,
      requestAt: began,
    };
    lab.nextClickAt = null;
    lab.events.push(event);
    lab.last = event;
    try {
      const masks =
        certificates.get(hintStateKey(state)) ??
        Array.from({ length: 81 }, (_, i) => computedCandidates(state, i));
      const values = Array.from({ length: 81 }, (_, i) => valueAt(state, i)).join("");
      const response = await fetch("/api/hint", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal,
        body: JSON.stringify({ engine, values, givens: state.givens.join(""), candidates: masks }),
      });
      const result = await response.json();
      if (!response.ok || result.error) throw Error(result.error ?? "Hint request failed");
      Object.assign(event, {
        responseAt: performance.now(),
        fetchMs: performance.now() - began,
        searchMs: result.searchMs,
        adapterMs: result.adapterMs,
        serverMs: result.serverMs,
        coldStartMs: result.coldStartMs,
        queueMs: result.queueMs,
        priorityPolicy: result.priorityPolicy,
      });
      if (!result.hint) {
        event.noResult = true;
        event.done = true;
        return null;
      }
      const hint = normalize(result.hint);
      event.technique = hint.name;
      event.effect = hint.effect;
      const next = applyHint(state, hint),
        after = [...masks];
      for (const p of hint.placements) {
        after[p.cell] = 0;
        for (const peer of PEERS[p.cell]) after[peer] &= ~bit(p.digit);
      }
      for (const p of hint.eliminations) after[p.cell] &= ~bit(p.digit);
      certificates.set(hintStateKey(next), after);
      event.normalizedAt = performance.now();
      return hint;
    } catch (error) {
      event.error = String(error);
      event.done = true;
      throw error;
    }
  };
  mount(App, { target: document.getElementById("app"), props: { hintProvider: provider } });
  await tick();
  game.load(fixture.state.givens.join(""));
  game.commitStroke(fixture.state);
  window.dispatchEvent(new CustomEvent("loadPuzzle"));
  timer.set(12 * 60 + 47);
  timerRunning.set(false);
  await tick();
  document.title = `Sudoku · ${engine} live prototype`;
  document.body.dataset.enginePrototype = "ready";
}
void start();
