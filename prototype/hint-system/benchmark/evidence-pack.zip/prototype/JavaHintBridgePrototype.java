// Disposable integration adapter, not an engine port. Run with the pinned SE JAR
// and HoDoKu classes on the classpath. One process handles sequential JSONL
// requests; a caller cancels long synchronous searches by killing this process.
import java.io.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import diuf.sudoku.*;
import diuf.sudoku.solver.*;
import sudoku.Sudoku2;
import sudoku.SudokuStatus;
import sudoku.SolutionStep;
import sudoku.SolutionType;
import sudoku.StepConfig;
import sudoku.Options;
import sudoku.Candidate;
import sudoku.Chain;
import solver.SudokuStepFinder;

public class JavaHintBridgePrototype {
  static final String[] SE_LISTS = {"directHintProducers", "indirectHintProducers", "chainingHintProducers", "chainingHintProducers2", "advancedHintProducers", "experimentalHintProducers"};
  static final String SE_VERSION = "SukakuExplainer 1.18.1 / 362854eea4e983017726d406ac9ee8a28909bcc7";
  static final String HD_VERSION = "PseudoFish/HoDoKu c37fe90bf1da7a95485d8f32a79060fa27dae47b";

  static Map<String,Object> map(Object... pairs) {
    Map<String,Object> result = new LinkedHashMap<>();
    for (int i = 0; i < pairs.length; i += 2) result.put((String)pairs[i], pairs[i + 1]);
    return result;
  }
  static Map<String,Object> candidate(int cell, int digit) { return map("cell",cell,"digit",digit); }
  static boolean peers(int a, int b) { return a / 9 == b / 9 || a % 9 == b % 9 || a / 27 == b / 27 && a % 9 / 3 == b % 9 / 3; }
  static String norm(String s) { return s.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT); }
  static String text(String html) {
    if (html == null) return "";
    return html.replace("\r", "").replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>", "")
      .replaceAll("(?i)<br\\s*/?>|</(?:p|li|h[1-6])>", "\n")
      .replaceAll("<[^>]*>", "")
      .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
      .replace("&quot;", "\"").replace("&#39;", "'").replace("&amp;", "&")
      .replaceAll("[ \\t]+", " ").replaceAll("\\n\\s*\\n+", "\n\n").trim();
  }

  static class Input {
    String values, givens, engine, technique;
    int[] masks = new int[81];
    Input(Map<String,Object> request) {
      engine = String.valueOf(request.getOrDefault("engine", "se"));
      if (!engine.equals("se") && !engine.equals("hodoku")) throw new IllegalArgumentException("engine must be se or hodoku");
      values = String.valueOf(request.get("values"));
      if (!values.matches("[0-9]{81}")) throw new IllegalArgumentException("values must contain 81 digits");
      givens = request.get("givens") == null ? values : String.valueOf(request.get("givens"));
      if (!givens.matches("[0-9]{81}")) throw new IllegalArgumentException("givens must contain 81 digits");
      for (int i = 0; i < 81; i++) if (givens.charAt(i) != '0' && givens.charAt(i) != values.charAt(i))
        throw new IllegalArgumentException("values must preserve the original givens");
      technique = request.get("techniqueId") == null ? "" : String.valueOf(request.get("techniqueId"));
      Object provided = request.get("candidates");
      if (provided != null && (!(provided instanceof List) || ((List<?>)provided).size() != 81))
        throw new IllegalArgumentException("candidates must contain 81 masks");
      for (int i = 0; i < 81; i++) {
        int v = values.charAt(i) - '0', legal = v == 0 ? 1022 : 0;
        for (int j = 0; j < 81; j++) if (i != j && peers(i,j)) {
          int d = values.charAt(j) - '0';
          if (d != 0) {
            if (v == d) throw new IllegalArgumentException("conflicting values at " + i + " and " + j);
            legal &= ~(1 << d);
          }
        }
        if (provided == null) masks[i] = legal;
        else {
          Object raw = ((List<?>)provided).get(i);
          if (!(raw instanceof Number) || ((Number)raw).doubleValue() != ((Number)raw).intValue())
            throw new IllegalArgumentException("candidate mask must be an integer");
          int mask = ((Number)raw).intValue();
          if (mask < 0 || (mask & ~legal) != 0) throw new IllegalArgumentException("candidate mask adds an illegal value at " + i);
          masks[i] = mask;
        }
        if (v == 0 && masks[i] == 0) throw new IllegalArgumentException("empty candidate set at " + i);
      }
    }
    Grid seGrid() {
      Grid g = new Grid(); g.fromString(values);
      for (int i = 0; i < 81; i++) {
        BitSet b = new BitSet(10);
        for (int d = 1; d <= 9; d++) if ((masks[i] & (1 << d)) != 0) b.set(d);
        g.setCellPotentialValues(i,b);
      }
      return g;
    }
    Sudoku2 hdGrid() {
      Sudoku2 g = new Sudoku2(); g.setSudoku(values);
      for (int i = 0; i < 81; i++) g.setIsFixed(i, givens.charAt(i) != '0');
      for (int i = 0; i < 81; i++) if (values.charAt(i) == '0')
        for (int d = 1; d <= 9; d++) if ((masks[i] & (1 << d)) == 0) g.delCandidate(i,d);
      g.setStatus(SudokuStatus.VALID); g.setStatusGivens(SudokuStatus.VALID);
      return g;
    }
  }

  static class Evidence {
    Map<String,Object> result;
    SortedSet<Integer> observe = new TreeSet<>(), premises = new TreeSet<>();
    List<Map<String,Object>> positive = new ArrayList<>(), negative = new ArrayList<>(), placements = new ArrayList<>(), eliminations = new ArrayList<>(), links = new ArrayList<>(), views = new ArrayList<>();
    String name, id, description, descriptionSource = "engine-explanation";
    Input input;
    Evidence(Input i) { input = i; }
    void add(List<Map<String,Object>> list, int cell, int digit) {
      if (cell < 0 || cell >= 81 || digit < 1 || digit > 9) return;
      Map<String,Object> p = candidate(cell,digit);
      if (!list.contains(p)) list.add(p);
    }
    List<Map<String,Object>> potentials(Map<Cell,BitSet> p) {
      List<Map<String,Object>> result = new ArrayList<>();
      if (p != null) for (Map.Entry<Cell,BitSet> entry : p.entrySet())
        for (int d = entry.getValue().nextSetBit(1); d >= 0; d = entry.getValue().nextSetBit(d + 1)) add(result,entry.getKey().getIndex(),d);
      return result;
    }
    void directPremises() {
      // If a placed single depends on a unit, retain filled peer blockers as
      // evidence too. Candidate masks remain the authoritative proof snapshot.
      for (Map<String,Object> p : placements) {
        int target = (Integer)p.get("cell"), digit = (Integer)p.get("digit");
        for (int i : new ArrayList<>(observe)) if (i != target && input.values.charAt(i) == '0')
          for (int j = 0; j < 81; j++) if (j != i && peers(i,j) && input.values.charAt(j) - '0' == digit) premises.add(j);
        add(positive,target,digit);
      }
    }
    Map<String,Object> finish() {
      Comparator<Map<String,Object>> byCandidate = Comparator
        .comparingInt((Map<String,Object> p) -> (Integer)p.get("cell"))
        .thenComparingInt(p -> (Integer)p.get("digit"));
      for (List<Map<String,Object>> list : Arrays.asList(positive,negative,placements,eliminations)) list.sort(byCandidate);
      for (Map<String,Object> p : positive) premises.add((Integer)p.get("cell"));
      for (Map<String,Object> p : negative) premises.add((Integer)p.get("cell"));
      observe.addAll(premises);
      for (Map<String,Object> p : placements) observe.add((Integer)p.get("cell"));
      for (Map<String,Object> p : eliminations) observe.add((Integer)p.get("cell"));
      for (Map<String,Object> p : eliminations) {
        int cell = (Integer)p.get("cell"), digit = (Integer)p.get("digit");
        if (input.values.charAt(cell) != '0' || (input.masks[cell] & (1 << digit)) == 0)
          throw new IllegalStateException("engine emitted an elimination absent from the input");
      }
      for (Map<String,Object> p : placements) {
        int cell = (Integer)p.get("cell"), digit = (Integer)p.get("digit");
        if (input.values.charAt(cell) != '0' || (input.masks[cell] & (1 << digit)) == 0)
          throw new IllegalStateException("engine emitted a placement absent from the input");
      }
      return map("techniqueId",id,"name",name,"description",description,"descriptionSource",descriptionSource,
        "observeCells",observe,"premiseCells",premises,"premiseCandidates",positive,
        "excludedCandidates",negative,"placements",placements,"eliminations",eliminations,
        "candidateMasks",input.masks,"links",links,"views",views,"viewCount",views.size());
    }
  }

  @SuppressWarnings("unchecked")
  static List<HintProducer> seProducers(Grid grid) throws Exception {
    Solver solver = new Solver(grid);
    List<HintProducer> result = new ArrayList<>();
    for (String field : SE_LISTS) {
      Field f = Solver.class.getDeclaredField(field); f.setAccessible(true);
      result.addAll((List<HintProducer>)f.get(solver));
    }
    return result;
  }

  static Map<String,Object> se(Input input) throws Exception {
    Grid grid = input.seGrid();
    if (!input.technique.isEmpty()) {
      SolvingTechnique selected = null;
      for (SolvingTechnique t : SolvingTechnique.values()) if (norm(t.name()).equals(norm(input.technique))) selected = t;
      if (selected == null) throw new IllegalArgumentException("unknown SE technique: " + input.technique);
      Settings.getInstance().setTechniques(EnumSet.of(selected));
    }
    List<HintProducer> producers;
    try { producers = seProducers(grid); }
    finally { Settings.getInstance().setTechniques(EnumSet.allOf(SolvingTechnique.class)); }
    Hint[] found = { null };
    List<String> searched = new ArrayList<>();
    long searchStart = System.nanoTime();
    for (HintProducer producer : producers) {
      searched.add(producer.getClass().getSimpleName());
      try {
        producer.getHints(grid,hint -> { found[0] = hint; throw new InterruptedException(); });
      } catch (InterruptedException stoppedAtFirstHint) { }
      if (found[0] != null) break;
    }
    double searchMs = (System.nanoTime() - searchStart) / 1e6;
    if (found[0] == null) return map("searchMs",searchMs,"searched",searched,"hint",null);
    Hint hint = found[0];
    Evidence e = new Evidence(input);
    e.name = hint instanceof Rule ? ((Rule)hint).getName() : hint.getClass().getSimpleName();
    e.id = e.name.replaceAll("[^A-Za-z0-9]", "");
    try { e.description = text(hint.toHtml(grid)); }
    catch (RuntimeException unavailableDescription) { e.description = hint.toString(); e.descriptionSource = "engine-short-description"; }
    Grid.Region[] regions = hint.getRegions();
    if (regions != null) for (Grid.Region region : regions) if (region != null)
      for (int i = 0; i < 9; i++) e.observe.add(region.getCell(i).getIndex());
    if (hint.getCell() != null) e.add(e.placements,hint.getCell().getIndex(),hint.getValue());
    if (hint instanceof IndirectHint) {
      IndirectHint indirect = (IndirectHint)hint;
      e.eliminations.addAll(e.potentials(indirect.getRemovablePotentials()));
      Cell[] cells = indirect.getSelectedCells();
      if (cells != null) for (Cell cell : cells) e.premises.add(cell.getIndex());
      for (int v = 0; v < indirect.getViewCount(); v++) {
        List<Map<String,Object>> green = e.potentials(indirect.getGreenPotentials(grid,v));
        List<Map<String,Object>> red = e.potentials(indirect.getRedPotentials(grid,v));
        List<Map<String,Object>> blue = e.potentials(indirect.getBluePotentials(grid,v));
        List<Map<String,Object>> viewLinks = new ArrayList<>();
        Collection<Link> ls = indirect.getLinks(grid,v);
        if (ls != null) for (Link link : ls) viewLinks.add(map("from",candidate(link.getSrcCell().getIndex(),link.getSrcValue()),"to",candidate(link.getDstCell().getIndex(),link.getDstValue())));
        e.views.add(map("positive",green,"negative",red,"blue",blue,"links",viewLinks));
        if (v == 0) {
          e.positive.addAll(green);
          for (Map<String,Object> p : red) if (!e.eliminations.contains(p)) e.negative.add(p);
          e.links.addAll(viewLinks);
        }
      }
    }
    e.directPremises();
    return map("searchMs",searchMs,"searched",searched,"hint",e.finish());
  }

  static Map<String,Object> hodoku(Input input) {
    Sudoku2 grid = input.hdGrid();
    SudokuStepFinder finder = new SudokuStepFinder(); finder.setSudoku(grid);
    List<SolutionType> types = new ArrayList<>();
    if (!input.technique.isEmpty()) {
      for (SolutionType type : SolutionType.values()) if (norm(type.name()).equals(norm(input.technique))) types.add(type);
      if (types.isEmpty()) throw new IllegalArgumentException("unknown HoDoKu technique: " + input.technique);
    } else {
      // Options.solverSteps is in native configured priority order, not enum order.
      for (StepConfig config : Options.getInstance().solverSteps) if (config.isEnabled()) {
        SolutionType type = config.getType();
        if (type != SolutionType.BRUTE_FORCE && type != SolutionType.GIVE_UP && type != SolutionType.INCOMPLETE) types.add(type);
      }
    }
    SolutionStep step = null;
    List<String> searched = new ArrayList<>();
    long searchStart = System.nanoTime();
    for (SolutionType type : types) {
      searched.add(type.name()); step = finder.getStep(type);
      if (step != null) break;
    }
    double searchMs = (System.nanoTime() - searchStart) / 1e6;
    if (step == null) return map("searchMs",searchMs,"searched",searched,"hint",null);
    Evidence e = new Evidence(input);
    e.id = step.getType().name(); e.name = step.getStepName();
    try { e.description = step.toString(2); }
    catch (RuntimeException unavailableDescription) { e.description = e.name; e.descriptionSource = "engine-short-description"; }
    e.premises.addAll(step.getIndices());
    int placedCount = step.getAnzSet();
    if (placedCount > 0 && !step.getValues().isEmpty())
      for (int i = 0; i < Math.min(placedCount,step.getIndices().size()); i++)
        e.add(e.placements,step.getIndices().get(i),step.getValues().get(Math.min(i,step.getValues().size()-1)));
    for (Candidate c : step.getCandidatesToDelete()) e.add(e.eliminations,c.getIndex(),c.getValue());
    for (int cell : step.getIndices()) for (int d : step.getValues())
      if ((input.masks[cell] & (1 << d)) != 0) e.add(e.positive,cell,d);
    for (Candidate c : step.getFins()) { e.add(e.positive,c.getIndex(),c.getValue()); e.premises.add(c.getIndex()); }
    for (Candidate c : step.getEndoFins()) { e.add(e.positive,c.getIndex(),c.getValue()); e.premises.add(c.getIndex()); }
    // Preserve full chain nodes (including grouped/ALS nodes) instead of
    // silently rendering group nodes as ordinary single-cell links.
    for (Chain chain : step.getChains()) {
      List<Object> nodes = new ArrayList<>();
      int[] raw = chain.getChain();
      for (int i = chain.getStart(); i <= chain.getEnd(); i++) {
        int entry = raw[i], cell = chain.getCellIndex(i), d = chain.getCandidate(i);
        nodes.add(map("raw",entry,"nodeType",chain.getNodeType(i),"cell",cell,"digit",d));
        if (chain.getNodeType(i) == Chain.NORMAL_NODE && cell >= 0 && cell < 81) {
          e.premises.add(cell); e.add(e.positive,cell,d);
        }
      }
      e.views.add(map("nodes",nodes));
    }
    // Source units that contain the full pattern are useful observation hints.
    for (int unit = 0; unit < 27; unit++) {
      List<Integer> cells = new ArrayList<>();
      for (int i = 0; i < 9; i++) cells.add(unit < 9 ? unit*9+i : unit < 18 ? (unit-9)+i*9 : (unit-18)/3*27+(unit-18)%3*3+i/3*9+i%3);
      int in = 0; for (int cell : e.premises) if (cells.contains(cell)) in++;
      if (in >= 2 && in == e.premises.size()) e.observe.addAll(cells);
    }
    e.directPremises();
    return map("searchMs",searchMs,"searched",searched,"hint",e.finish());
  }

  @SuppressWarnings("unchecked")
  public static void main(String[] args) throws Exception {
    PrintStream protocol = System.out;
    System.setOut(System.err); // Third-party diagnostics never corrupt JSONL.
    Locale.setDefault(Locale.ENGLISH);
    Settings.getInstance().setNumThreads(1);
    Settings.getInstance().setTechniques(EnumSet.allOf(SolvingTechnique.class));
    Options.resetAll();
    System.err.println("READY JavaHintBridgePrototype se+hodoku");
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8));
    String line;
    while ((line = in.readLine()) != null) {
      if (line.isBlank()) continue;
      Object id = null;
      try {
        long start = System.nanoTime();
        Object parsed = new Json(line).parse();
        if (!(parsed instanceof Map)) throw new IllegalArgumentException("request must be an object");
        Map<String,Object> request = (Map<String,Object>)parsed;
        id = request.get("id"); Input input = new Input(request);
        Map<String,Object> result = input.engine.equals("se") ? se(input) : hodoku(input);
        result.put("id",id); result.put("engine",input.engine);
        result.put("engineVersion",input.engine.equals("se") ? SE_VERSION : HD_VERSION);
        result.put("priorityPolicy", "engine-native-first-result");
        result.put("assumptions", Arrays.asList("classic-9x9", "caller-certified-candidates", "unique-original-puzzle-for-uniqueness-techniques"));
        result.put("adapterMs",(System.nanoTime()-start)/1e6);
        protocol.println(Json.stringify(result)); protocol.flush();
      } catch (Throwable e) {
        protocol.println(Json.stringify(map("id",id,"error",e.getClass().getSimpleName()+": "+e.getMessage())));
        protocol.flush();
      }
    }
  }

  // Minimal RFC-8259 parser/writer for this local prototype protocol.
  static class Json {
    String s; int at;
    Json(String input) { s = input; }
    Object parse() { Object value = value(); space(); if (at != s.length()) throw new IllegalArgumentException("trailing JSON data"); return value; }
    void space() { while (at < s.length() && Character.isWhitespace(s.charAt(at))) at++; }
    char take() { if (at >= s.length()) throw new IllegalArgumentException("unexpected JSON end"); return s.charAt(at++); }
    Object value() {
      space(); char c = take();
      if (c == '"') return string();
      if (c == '{') {
        Map<String,Object> map = new LinkedHashMap<>(); space();
        if (at < s.length() && s.charAt(at) == '}') { at++; return map; }
        while (true) {
          space(); if (take() != '"') throw new IllegalArgumentException("object key expected");
          String key = string(); space(); if (take() != ':') throw new IllegalArgumentException(": expected");
          map.put(key,value()); space(); char next = take(); if (next == '}') return map;
          if (next != ',') throw new IllegalArgumentException(", expected");
        }
      }
      if (c == '[') {
        List<Object> list = new ArrayList<>(); space();
        if (at < s.length() && s.charAt(at) == ']') { at++; return list; }
        while (true) { list.add(value()); space(); char next = take(); if (next == ']') return list; if (next != ',') throw new IllegalArgumentException(", expected"); }
      }
      at--;
      for (String literal : new String[]{"true","false","null"}) if (s.startsWith(literal,at)) {
        at += literal.length(); return literal.equals("null") ? null : literal.equals("true");
      }
      int start = at;
      while (at < s.length() && "-+0123456789.eE".indexOf(s.charAt(at)) >= 0) at++;
      if (start == at) throw new IllegalArgumentException("JSON value expected");
      String number = s.substring(start,at);
      return number.indexOf('.') >= 0 || number.indexOf('e') >= 0 || number.indexOf('E') >= 0 ? Double.valueOf(number) : Long.valueOf(number);
    }
    String string() {
      StringBuilder b = new StringBuilder();
      while (true) {
        char c = take(); if (c == '"') return b.toString();
        if (c == '\\') {
          c = take();
          if (c == 'u') { if (at + 4 > s.length()) throw new IllegalArgumentException("bad unicode escape"); b.append((char)Integer.parseInt(s.substring(at,at+4),16)); at += 4; }
          else { int i = "\"\\/bfnrt".indexOf(c); if (i < 0) throw new IllegalArgumentException("bad JSON escape"); b.append(new char[]{'"','\\','/','\b','\f','\n','\r','\t'}[i]); }
        } else { if (c < 32) throw new IllegalArgumentException("control character in string"); b.append(c); }
      }
    }
    static String stringify(Object value) {
      if (value == null) return "null";
      if (value instanceof String) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : ((String)value).toCharArray()) {
          if (c == '"' || c == '\\') b.append('\\').append(c);
          else if (c < 32) b.append(String.format("\\u%04x",(int)c)); else b.append(c);
        }
        return b.append('"').toString();
      }
      if (value instanceof Map) {
        List<String> entries = new ArrayList<>();
        for (Object entryObject : ((Map<?,?>)value).entrySet()) { Map.Entry<?,?> e = (Map.Entry<?,?>)entryObject; entries.add(stringify(String.valueOf(e.getKey()))+":"+stringify(e.getValue())); }
        return "{"+String.join(",",entries)+"}";
      }
      if (value instanceof Iterable) { List<String> entries = new ArrayList<>(); for (Object e : (Iterable<?>)value) entries.add(stringify(e)); return "["+String.join(",",entries)+"]"; }
      if (value.getClass().isArray()) { List<String> entries = new ArrayList<>(); for (int i=0;i<Array.getLength(value);i++) entries.add(stringify(Array.get(value,i))); return "["+String.join(",",entries)+"]"; }
      if (value instanceof Number || value instanceof Boolean) return value.toString();
      throw new IllegalArgumentException("unsupported JSON output: " + value.getClass());
    }
  }
}
